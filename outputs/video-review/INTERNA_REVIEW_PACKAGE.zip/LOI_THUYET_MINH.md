# Lời thuyết minh — Interna

## 00:00 — Học từ công việc thật.

Xin chào ban giám khảo và các bạn! Đây là Interna, không gian đào tạo và kèm cặp thực tập sinh công nghệ với trợ lý trí tuệ nhân tạo. Hãy cùng khám phá sản phẩm qua một vòng làm việc thực tế.

## 00:13 — Một bài toán. Hai phía áp lực.

Khi đào tạo nhân sự mới, người hướng dẫn phải trả lời nhiều câu hỏi lặp lại, nhưng vẫn khó nhìn thấy quá trình tự học. Ở chiều ngược lại, thực tập sinh bỡ ngỡ với quy chuẩn công ty và dễ phụ thuộc vào việc sao chép câu trả lời từ công cụ tạo mã. Làm sao để học nhanh hơn mà vẫn hiểu bản chất?

## 00:33 — Gợi mở tư duy. Lưu lại quá trình.

Interna kết nối ba thành phần: nhiệm vụ thực tế, kho tài liệu nội bộ và người hướng dẫn. Trợ lý đóng vai trò người thầy nghiêm khắc: gợi mở cách giải quyết, nhắc quy chuẩn và khuyến khích người học tự thực hiện. Lịch sử tương tác trở thành minh chứng để người hướng dẫn trao đổi và đánh giá.

## 00:52 — Từ MVP đến hệ sinh thái nhiều tác tử

Lộ trình có ba mốc. Ba mươi phần trăm là bản hiện tại: giao diện hai vai trò, luồng nộp và duyệt bài, cùng truy xuất tài liệu bằng ChromaDB. Kiến trúc hỗ trợ chuyển giữa Ollama nội bộ và Gemini trên đám mây. Mốc sáu mươi phần trăm dự kiến bổ sung cơ sở dữ liệu tập trung và triển khai bằng Docker lên Cloud Run. Mốc một trăm phần trăm hướng tới nhiều tác tử chuyên trách và báo cáo năng lực.

## 01:18 — Bắt đầu từ nhiệm vụ được giao

Bây giờ là thao tác thực tế. Tôi vào tài khoản mẫu của Hữu Đạt, chọn nhiệm vụ thiết kế dữ liệu. Màn hình đặt yêu cầu, danh sách kết quả cần đạt, tài liệu liên quan và khung trợ lý cạnh nhau. Người học biết mình cần làm gì và tìm thông tin ở đâu.

## 01:35 — Đọc yêu cầu trước khi viết mã

Mở tài liệu yêu cầu dự án, ta thấy bảy trường của hồ sơ thực tập sinh. Mã phải duy nhất, ngày kết thúc không được trước ngày bắt đầu. Tiêu chí nghiệm thu được trình bày rõ ràng, và lần mở tài liệu này cũng được lưu vào lịch sử hoạt động.

## 01:51 — Thử nhờ AI làm bài hộ

Thử yêu cầu: anh chị viết hộ em code bài này với! Phản hồi thật từ mô hình nội bộ đã xuất hiện. Thay vì đưa một bài giải hoàn chỉnh, trợ lý nhắc quy tắc tự học, dẫn tài liệu và hỏi lại về cấu trúc dữ liệu cùng cách kiểm tra ngày tháng. Đây là điểm nhấn: trợ lý giúp người học tiếp tục suy nghĩ.

## 02:11 — Hỏi nghiệp vụ, tìm lại quy chuẩn

Tiếp theo: nếu mã thực tập sinh bị trùng thì xử lý thế nào? Trợ lý trả lời theo quy định mã duy nhất, kèm nguồn tài liệu để đối chiếu. Người học có thể quay lại yêu cầu gốc và tự đề xuất cách xử lý. Đây là luồng truy xuất tài liệu hỗ trợ trả lời, đang chạy qua backend của sản phẩm.

## 02:31 — Nộp cả kết quả và điều còn vướng

Tôi bắt đầu nhiệm vụ, đánh dấu các mục đã thực hiện và nhập kết quả: đã đọc yêu cầu, đề xuất hồ sơ gồm bảy trường dữ liệu. Phần vướng mắc nêu rõ câu hỏi: nên kiểm tra ngày tháng ở phía giao diện hay máy chủ? Bấm gửi người hướng dẫn xem, nhiệm vụ chuyển sang chờ duyệt. Việc nộp bài luôn đi cùng giải thích quá trình.

## 02:53 — Hiểu quá trình trước khi đánh giá

Chuyển sang tài khoản người hướng dẫn, ta thấy danh sách thực tập sinh và bài đang chờ. Chọn Hữu Đạt để xem dấu vết làm việc: đã mở tài liệu nào, hỏi trợ lý điều gì và nhận phản hồi ra sao. Những dữ liệu này bổ sung ngữ cảnh cho buổi trao đổi; quyết định đánh giá vẫn thuộc về người hướng dẫn.

## 03:13 — Một vòng phản hồi hai chiều

Mở bài gửi để đọc kết quả và vướng mắc. Tôi phản hồi: cần kiểm tra ở cả giao diện lẫn máy chủ, để vừa hướng dẫn người dùng, vừa bảo vệ tính hợp lệ của dữ liệu. Sau khi xem bài và giải đáp câu hỏi, người hướng dẫn chọn duyệt hoàn thành. Trạng thái chuyển sang màu xanh, và tiến độ được cập nhật.

## 03:33 — Mở rộng nhóm thực tập

Người hướng dẫn cũng có thể thêm hồ sơ thực tập sinh mới. Ở đây tôi tạo hồ sơ mẫu Nguyễn Văn An, vị trí lập trình phía máy chủ. Bản hiện tại là môi trường minh họa: đăng nhập được mô phỏng và dữ liệu nghiệp vụ lưu trên trình duyệt đang dùng.

## 03:49 — Từ hỗ trợ học tập đến vận hành đội ngũ

Trong tương lai, Interna dự kiến tích hợp tác tử kiểm tra mã và bảo mật vào quy trình duyệt thay đổi trên Git. Báo cáo năng lực có thể tổng hợp từ bài làm và lịch sử trao đổi để hỗ trợ đánh giá cuối kỳ. Hướng phát triển tiếp theo là dịch vụ cho doanh nghiệp và trường đại học, với dữ liệu tập trung và phân quyền thực tế.

## 04:10 — Lớn lên từ mỗi nhiệm vụ.

Interna hướng tới một vòng học tập trọn vẹn: nhận việc, tự tìm hiểu, thực hành và nhận phản hồi. Cảm ơn ban giám khảo và các bạn đã theo dõi bản giới thiệu sản phẩm!
